/*
 * La clase Consumidor define hilos que leen mensajes de un buzón de mensajes
 * y los muestran por pantalla.
 * El buzón y el número de mensajes, los reciben como parámetros del constructor
 * antes de terminar.
 * Entre lectura y lectura, esperan un tiempo aleatorio entre 0.5 y 1 seg.
 */


public class Consumidor extends Thread
{
    private String nombre;
    private Buzon buzon;

    //constructor

    public Consumidor(String nombre, Buzon buzon) {
        this.nombre = nombre;
        this.buzon = buzon;
    }
    

    public void sacarNumeroBuffer()
    {
        buzon.sacarNumero(nombre);
        try 
        {
            sleep((int) (300 + 400 * Math.random()));
        } 
        catch (InterruptedException e) 
        {
            System.out.println("Error en meterNumeroBuffer()");
        }
    }
            
            
    @Override
    public void run()
    {
        while(true)  //de esta manera nunca acaba
        {
            sacarNumeroBuffer();
        }
    }
}
