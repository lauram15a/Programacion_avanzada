
import java.util.ArrayList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/*
 * La clase Buzon tiene que estar protegida con un cerrojo
 * El método enviaMensaje debe esperar si el buzón está lleno
 * El método recibeMensaje debe esperar si el buzón está vacío.
 * Cuando un hilo completa su operación, desbloquea a los que estén esperando
 * para que puedan continuar intentando su acción.
 */


public class Buzon
{
    private ArrayList buzoon = new ArrayList();
    private int numNumerosMax;      //15
    private int numNumeros = 0;
    private int resultado = 0;
    private Lock cerrojo = new ReentrantLock();
    private Condition buzonLleno = cerrojo.newCondition();
    private Condition buzonVacio = cerrojo.newCondition();

    //constructor
    public Buzon(int numNumeross) 
    {
        this.numNumerosMax = numNumeross;  //15
    }    
          
    public void meterNumero (String nombre, int num, int i)
    {
        cerrojo.lock();
        try
        {
            while (numNumeros >= numNumerosMax)
            {
                try
                {
                    buzonLleno.await();
                }
                catch(InterruptedException e)
                {
                    System.out.println("Error en meterNumero()" + e);
                } 
            }
            buzonVacio.signal();
            buzoon.add(num); //meter numero
            numNumeros++;
            System.out.println(nombre + " genera " + num + "     -- Ha generado en total: " + i);
            imprimir();
        }
        finally
        {
            
            cerrojo.unlock();
        }
    }
    
    public void sacarNumero (String nombre)
    {
        cerrojo.lock();
        try
        {
            
            while (numNumeros == 0)
            {
                try
                {
                    buzonVacio.await();
                }
                catch(InterruptedException e)
                {
                    System.out.println("Error en sacarNumero()" + e);
                } 
            }
            buzonLleno.signal();
            resultado = resultado + ((int)buzoon.get(0));
            System.out.println(nombre + " ha leido:  " + buzoon.get(0) + "    Suma:" + resultado);
            buzoon.remove(0);
            numNumeros--;
            imprimir();
        }
        finally
        {
            
            cerrojo.unlock();
        }
    }
    
    public void imprimir()
    {
        for (int i= 0; i < (buzoon.size()); i++)
        {
            System.out.print(buzoon.get(i) + "-");
        }
        System.out.println("");
    }
}