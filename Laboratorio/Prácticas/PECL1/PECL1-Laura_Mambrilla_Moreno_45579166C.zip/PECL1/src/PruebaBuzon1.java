/* Laura Mambrilla Moreno
    GII 2ºA

 * Programa que lanza cuatro lectores y un escritor.
 * que se comunican a través de un buzón de mensajes.
 * Debe comprobarse que no se pierden los mensajes ni se leen dos veces
 */


public class PruebaBuzon1
{
    public static void main(String[] s)
    {
        Buzon buzonX = new Buzon(15);
        
        //Productores
        Productor a = new Productor("A ", 80, buzonX);
        Productor b = new Productor("B ", 80, buzonX);
        Productor c = new Productor("C ", 80, buzonX);
        
        //consumidores
        Consumidor jose = new Consumidor("Jose", buzonX);
        Consumidor ana = new Consumidor ("Ana", buzonX);
        Consumidor maria = new Consumidor ("Maria", buzonX);
        
        //hilos start
        a.start();
        b.start();
        c.start();
        jose.start();
        ana.start();
        maria.start();
        
        /*
        try
        {
            a.join();
            b.join();
            c.join();
        }
        catch (InterruptedException e)
        {
            System.out.println("Error en los join");
        }
*/
    }
}
