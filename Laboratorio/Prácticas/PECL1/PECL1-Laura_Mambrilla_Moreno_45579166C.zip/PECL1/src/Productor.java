


/*
 * La clase Productor define hilos que envían mensajes a un buzón de mensajes.
 * Los mensajes constan de un prefijo String y un sufijo que es un entero del 1 al 5
 * El prefijo, el número de mensajes a escribir y el buzón donde hacerlo,
 *  se reciben como parámetros en el constructor.
 * Entre mensaje y mensaje, esperan un tiempo aleatorio entre 0.5 y 1 seg.
 */



public class Productor extends Thread
{
    private String nombre;
    private int numNumeros;
    private Buzon buzon;
    private int contador = 0;

    public Productor(String nombree, int n, Buzon buzonn)
    {
        this.nombre=nombree;
        numNumeros=n;
        buzon=buzonn;
    }

    public void meterNumeroBuffer(int i)
    {
        int numero = (int) (0 + 200 * Math.random());  //Rango aleatorios int  (de 1000 a 1500)
        contador++;
        buzon.meterNumero(nombre, numero, i);
        try 
        {
            sleep((int) (200 + 600 * Math.random()));
        } 
        catch (InterruptedException e) 
        {
            System.out.println("Error en meterNumeroBuffer()");
        }
    }
    
    @Override
    public void run()
    {
        for(int i=1; i<(numNumeros+1); i++)
        {
            meterNumeroBuffer(i);            
        }
    }
}
